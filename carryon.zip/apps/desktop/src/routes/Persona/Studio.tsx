export default function Studio() {
  return (
    <main className="p-8">
      <h2 className="text-xl font-bold mb-4">Persona Studio</h2>
      <div>
        <p>Live preview, tone/style rules editing goes here.</p>
      </div>
    </main>
  );
}