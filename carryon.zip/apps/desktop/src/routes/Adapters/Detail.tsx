export default function AdapterDetail() {
  return (
    <main className="p-8">
      <h2 className="text-xl font-bold mb-4">Adapter Details</h2>
      <div>
        <p>Provider details, tone check, roundtrip test here.</p>
      </div>
    </main>
  );
}