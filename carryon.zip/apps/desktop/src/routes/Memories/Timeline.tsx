export default function Timeline() {
  return (
    <main className="p-8">
      <h2 className="text-xl font-bold mb-4">Memory Timeline</h2>
      <div>
        <p>Timeline and search/filter UI will be built here.</p>
      </div>
    </main>
  );
}